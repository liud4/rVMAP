library(testthat)
library(secret)

test_check("secret")
