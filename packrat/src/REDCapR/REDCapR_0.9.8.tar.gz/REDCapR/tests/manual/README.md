The tests in this directory are somewhat invasive, so they must be run by hand,
and therefore are kept separate from the automated tests.

This follows the testing approach of Winston Chang's [R6](https://github.com/wch/R6/tree/master/tests/manual) package.
